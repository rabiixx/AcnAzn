package journal;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.security.AccessControlException;
import java.security.GeneralSecurityException;
import java.security.PrivilegedAction;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.security.auth.Subject;

public final class AddNote implements PrivilegedAction<Boolean>{
  
    static private final String CLASS_NAME = AddNote.class.getName();
    static private final Logger LOGGER = Logger.getLogger(CLASS_NAME);
  
    static private final int ITERATIONS = 2048;
  
    private final Subject subject;
    private final String filename;
    private final String note;
    
    protected AddNote ( final Subject subject, final String filename, final String note ) {
        this.subject = subject;
        this.filename = filename;
        this.note = note;
    }
    
    private Boolean add (final String filename, final String note) {

        try {

            System.out.print("Introduce contraseña para encriptar la nota: ");
            final char[] passwd = System.console().readPassword();

            AESCipherGenerator acg = new AESCipherGenerator();

            /* Obtenemos el cipher a utilizar para encriptar el mensaje*/
            Cipher cipher = acg.getEncrypter(passwd, ITERATIONS);

            /* Enctiptamos el mensaje y nos lo devulve encriptado */
            byte[] encryptedMsg = cipher.doFinal( note.getBytes() );

            /* Codificamos el mensaje encriptado en base64 */
            String encodedMsg = Base64.getEncoder().encodeToString( encryptedMsg );

            /** 
              * Obtenemos los parámetros (pizca de sal, iteraciones y vector de 
              * inicialización utilizados por el cipher para poder desencriptar 
              * el mensaje posteriormente.
              */
            final byte[] params = cipher.getParameters().getEncoded();

            /* Al igual que el mensaje, codificamos los paramentros en base64 */
            final String base64Params = Base64.getEncoder().encodeToString(params);


            final String journalPath = System.getProperty("user.dir") + File.separator
                + "users" + File.separator + filename;

            final File journalFile = new File(journalPath);

            /**
             * Escribimos el mensaje encriptado y los parámetros utilizados para
             * su encriptacion en el fichero journal.data con el siguiente formato:
             * formato: encodedMsg:encodedParams
             */
            try (FileWriter os = new FileWriter(journalFile, true)) {
                os.write(encodedMsg + ":" + base64Params + "\n");
                return Boolean.TRUE;
            } catch (final IOException ex) {
                LOGGER.log(Level.SEVERE, ex.getMessage(), ex.getCause());
                return false;
            }
            
        } catch ( IOException | GeneralSecurityException ex ) {
            LOGGER.log(Level.SEVERE, ex.getMessage(), ex.getCause());
            return Boolean.FALSE;
        }
        
    }
    
    @Override
    public Boolean run() {
        try {
            return Subject.doAsPrivileged(subject, ( PrivilegedAction<Boolean> ) () -> add( filename, note ), null);
        } catch ( final AccessControlException ex ) {
            LOGGER.log( Level.WARNING, "sujeto sin permisos", ex );
            System.out.println( "Error: " + ex.getMessage() );
            return Boolean.FALSE;
        }
    }
}