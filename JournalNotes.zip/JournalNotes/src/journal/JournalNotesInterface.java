package journal;

import java.security.AccessControlException;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.Subject;

public class JournalNotesInterface {

    static private final String CLASS_NAME = JournalNotesInterface.class.getName();
    static private final Logger LOGGER = Logger.getLogger(CLASS_NAME);
    
    public String read( final Subject subject, final String filename, final int n ) {
        try {
            final PrivilegedAction<String> readNote = new ReadNote( subject, filename, n );
            return AccessController.doPrivileged( readNote );
        } catch ( final AccessControlException ex ) {
            LOGGER.log(Level.WARNING, "problema de permisos", ex);
            System.out.println("Error: " + ex.getMessage());
            return "";
        }
    }
    
    public Boolean add( final Subject subject, final String filename, final String note ) {
        try {
            final PrivilegedAction<Boolean> addNote = new AddNote( subject, filename, note );
            return AccessController.doPrivileged( addNote );
        } catch ( final AccessControlException ex ) {
            LOGGER.log(Level.WARNING, "problema de permisos", ex);
            System.out.println("Error: " + ex.getMessage());
            return Boolean.FALSE;
        }
    }

}
