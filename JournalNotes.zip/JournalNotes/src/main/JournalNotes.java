package main;

import com.sun.security.auth.callback.TextCallbackHandler;
import java.security.AccessControlException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import journal.JournalNotesInterface;

public final class JournalNotes {
    
    static private final String CLASS_NAME = JournalNotes.class.getName();
    static private final Logger LOGGER = Logger.getLogger(CLASS_NAME);

    public static void main ( final String[] args ) {
        
        final LoginContext loginContext;
        
        try {
            loginContext = new LoginContext("JOURNALNOTES", new TextCallbackHandler());
        } catch (final LoginException ex) {
            System.out.println("No configuration entry to create specified LoginContext");
            return;
        } catch (final SecurityException ex) {
            System.out.println("No permission to create specified LoginContext (" + ex.getMessage() + ")");
            return;
        }

        try {

            loginContext.login();

            final Subject subject = loginContext.getSubject();

            menu(subject);

            try {
                System.out.println("4");
                loginContext.logout();
            } catch (final LoginException ex) {
                LOGGER.log(Level.SEVERE, "Fallo al eliminar el contexto de login", ex.getCause());
                System.out.println("Fallo al eliminar el contexto de login");
            }
        
        } catch (final LoginException ex) {
            LOGGER.log(Level.WARNING, "Autenticación fallida en arranque de la aplicación", ex.getCause());
            System.out.println("Autenticación fallida en arranque de la aplicación");
        } catch (final AccessControlException ex) {
            LOGGER.log(Level.WARNING, "Problema de permisos en arranque de aplicación", ex.getCause());
            System.out.println("Problema de permisos en arranque de aplicación"); 
            System.out.println(ex);
        }
    }
    
    private static void menu ( final Subject subject ) {

        final JournalNotesInterface journalNotesInterface = new JournalNotesInterface();
        final Scanner scanner = new Scanner(System.in);
        int opcion;
        do {

            System.out.println("Opciones:");
            System.out.println("  1 - Añadir nota");
            System.out.println("  2 - Leer nota");
            System.out.println("  0 - Salir");
            System.out.print("Introduce opcion: ");
            try {

                opcion = scanner.nextInt();
                scanner.nextLine();

                final String filename;
                final String note;
                switch (opcion) {
                    case 1:
                        System.out.print("Introduce nombre de fichero: ");
                        filename = scanner.next();
                        scanner.nextLine();
                        System.out.print("Introduce nota a depositar: ");
                        note = scanner.next();
                        scanner.nextLine();
                        
                        if ( journalNotesInterface.add( subject, filename, note ) ) {
                            System.out.println("Nota guardada");
                        } else {
                            System.err.println("Problema al guardar la nota");
                        }
                        break;
                    case 2:
                        System.out.print("Introduce nombre de fichero: ");
                        filename = scanner.next();
                        scanner.nextLine();
                        System.out.print("Introduce numero de nota: ");
                        final int n = scanner.nextInt();
                        scanner.nextLine();
                        
                        note = journalNotesInterface.read( subject, filename, n );
                        if ( !note.equals("") )
                            System.out.println("Contenido de nota leida: " + note);
                        else
                            System.out.println("Problema al leer la nota");
                        break;
                    default:
                }
            } catch (final InputMismatchException ex) {
                scanner.nextLine();
                opcion = Integer.MAX_VALUE;
            }
	
	} while (opcion != 0);

    }
}