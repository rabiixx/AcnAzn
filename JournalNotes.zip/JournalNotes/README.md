# JournalNotes
Programacion Segura - Practica 2
